/**
 * Downloads / verifies the built-in MongoDB binary during SETUP (before seed).
 */
import "dotenv/config";
import { closeDB, connectDB } from "./config/db.js";

console.log("  → Connecting to built-in database engine…");
console.log("  → First time: downloads ~600MB then starts (2–5 min on slow PCs)…");
console.log("  → Please wait — do not close this window…");

await connectDB(process.env.MONGO_URI || "");

console.log("  → Built-in database engine is ready.");
await closeDB();
process.exit(0);
