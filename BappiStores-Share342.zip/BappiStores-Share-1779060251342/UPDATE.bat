@echo off
setlocal
title Bappi Stores - Update
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js from https://nodejs.org
  pause
  exit /b 1
)

echo.
echo  ==================================================
echo   BAPPI STORES - UPDATE
echo  ==================================================
echo.
echo  Progress below. Do NOT close this window.
echo  Log saved to update-log.txt
echo.

node "%~dp0scripts\update.mjs"
if errorlevel 1 (
  echo.
  echo  UPDATE FAILED — see messages above and update-log.txt
  echo.
  pause
  exit /b 1
)

echo.
pause
exit /b 0
