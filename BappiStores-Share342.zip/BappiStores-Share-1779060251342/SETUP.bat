@echo off
setlocal
title Bappi Stores - Setup
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed.
  echo  Download LTS from https://nodejs.org
  echo  Install it, restart this PC, then run SETUP.bat again.
  echo.
  pause
  exit /b 1
)

echo.
echo  ==================================================
echo   BAPPI STORES - SETUP
echo  ==================================================
echo.
echo  Progress will show below in real time.
echo  This can take 5-15 minutes. Do NOT close this window.
echo  A copy is also saved to setup-log.txt
echo.

node "%~dp0scripts\install.mjs"
if errorlevel 1 (
  echo.
  echo  ==================================================
  echo   SETUP FAILED
  echo  ==================================================
  echo  See messages above and setup-log.txt
  echo.
  pause
  exit /b 1
)

echo.
pause
exit /b 0
