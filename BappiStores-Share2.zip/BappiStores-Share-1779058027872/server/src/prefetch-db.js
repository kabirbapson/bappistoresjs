/**
 * Downloads / verifies the built-in MongoDB binary during SETUP (before seed).
 */
import "dotenv/config";
import { closeDB, connectDB } from "./config/db.js";

await connectDB(process.env.MONGO_URI || "");
console.log("Built-in database engine is ready.");
await closeDB();
process.exit(0);
