/**
 * Creates BappiStores-Share/ — zip this folder and send to other computers.
 * Run: npm run build:share
 */
import { randomBytes } from 'crypto'
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'fs'
import { dirname, join } from 'path'
import { fileURLToPath } from 'url'
import { runNpm } from './spawn-utils.mjs'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
let dest = join(root, 'BappiStores-Share')

function prepareDestFolder() {
  if (!existsSync(dest)) {
    mkdirSync(dest, { recursive: true })
    return
  }
  try {
    rmSync(dest, { recursive: true, force: true, maxRetries: 3, retryDelay: 500 })
    mkdirSync(dest, { recursive: true })
  } catch (err) {
    if (err.code === 'EBUSY' || err.code === 'EPERM') {
      dest = join(root, `BappiStores-Share-${Date.now()}`)
      console.warn(`\n  Folder locked — using ${dest} instead.\n`)
      mkdirSync(dest, { recursive: true })
      return
    }
    throw err
  }
}

const COPY_DIRS = ['client', 'server', 'scripts']

const COPY_FILES = [
  'package.json',
  'package-lock.json',
  'README.md',
  'SETUP.txt',
  'UPGRADE.txt',
  'SETUP.bat',
  'START.bat',
  'UPDATE.bat',
  'BACKUP.bat',
  'CONFIGURE-HOSTNAME.bat',
  'REPAIR-DATABASE.bat',
  'scripts/repair-database.bat',
  'SETUP.command',
  'START.command',
  'UPDATE.command',
  'BACKUP.command',
]

const SKIP_DIR_NAMES = new Set([
  'node_modules',
  '.git',
  '.cursor',
  '.vscode',
  'BappiStores-Share',
  'Backups',
])

function shouldSkipFile(name) {
  return name === '.env' || name === '.setup-complete' || name === '.DS_Store'
}

function copyDir(src, dst) {
  mkdirSync(dst, { recursive: true })
  for (const entry of readdirSync(src, { withFileTypes: true })) {
    if (SKIP_DIR_NAMES.has(entry.name)) continue
    if (entry.isDirectory()) {
      copyDir(join(src, entry.name), join(dst, entry.name))
    } else if (entry.isFile()) {
      if (shouldSkipFile(entry.name)) continue
      cpSync(join(src, entry.name), join(dst, entry.name))
    }
  }
}

console.log('Building share package...\n')

console.log('Step 1 — Build shop UI (client/dist)…')
try {
  runNpm(['run', 'build'], join(root, 'client'))
} catch (err) {
  console.error('\nBuild failed:', err.message)
  process.exit(1)
}

console.log('\nStep 2 — Copy files to BappiStores-Share/…\n')

prepareDestFolder()

for (const file of COPY_FILES) {
  const src = join(root, file)
  if (existsSync(src)) {
    cpSync(src, join(dest, file))
    console.log(`  + ${file}`)
  }
}

for (const dir of COPY_DIRS) {
  const src = join(root, dir)
  if (existsSync(src)) {
    copyDir(src, join(dest, dir))
    console.log(`  + ${dir}/`)
  }
}

console.log('\nStep 3 — Shop config files (server/.env + client/.env)…')
function shopServerEnv() {
  const tpl = readFileSync(join(root, 'server/.env.example'), 'utf8')
  return tpl.replace('JWT_SECRET=change-this-secret', `JWT_SECRET=${randomBytes(24).toString('hex')}`)
}
writeFileSync(join(dest, 'server', '.env'), shopServerEnv())
writeFileSync(join(dest, 'client', '.env'), readFileSync(join(root, 'client/.env.example'), 'utf8'))
mkdirSync(join(dest, 'data'), { recursive: true })
mkdirSync(join(dest, 'server', 'uploads', 'products'), { recursive: true })
console.log('  + server/.env (built-in database, port 5001)')
console.log('  + client/.env (production API paths)')
console.log('  + data/ and server/uploads/products/ folders')

writeFileSync(
  join(dest, 'READ-ME-FIRST.txt'),
  `BAPPI STORES — READ THIS FIRST
==============================

NEW COMPUTER (first time)
-------------------------
1. Install Node.js LTS from https://nodejs.org
2. Double-click SETUP.bat (Windows) or SETUP.command (Mac)
   (Config files are included — needs internet once for database engine)
3. Once: CONFIGURE-HOSTNAME.bat as Administrator (Windows)
4. Every day: START.bat / START.command
5. Browser: http://bappistores:5001
   Login: admin@bappi.com / admin123

ALREADY USING BAPPI STORES? (software update)
---------------------------------------------
Read UPGRADE.txt — use UPDATE.bat, NOT SETUP.bat.
Your sales stay in the  data/mongodb  folder.
Run BACKUP.bat before updating (recommended).

Do NOT delete:
  data/mongodb     — all sales, products, customers, debts
  server/uploads   — product photos you uploaded

Database error (EFTYPE)? Run REPAIR-DATABASE.bat then SETUP.bat again.
Setup failed? Open setup-log.txt (Windows) and send to IT.

More help: SETUP.txt and UPGRADE.txt
`,
)

console.log(`\nDone → ${dest}`)
console.log('Zip the BappiStores-Share folder and send it to shop computers.')
console.log('Do not include node_modules or data/ in the zip — setup creates those.\n')
